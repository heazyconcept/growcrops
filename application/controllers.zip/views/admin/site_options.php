<div class="main">
    <div class="outer-admin">
        <div class="wrapper-admin">
            <?php $this->load->view('templates/admin_menu'); ?>

            <div class="content-admin">
                <div class="content-admin-wrapper">
                    <div class="content-admin-main">
                        <div class="content-admin-main-inner">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-sm-12">






<div class="row">
  <div class="container">
    <h3 class="admin_section_title">Site Options</h3>
  </div>

    <div class="col-sm-12 col-md-7">
        <div class="users">
<table class="table">
    <tbody>
        <tr>
          <td class="hidden-xs visible-sm visible-md visible-lg">
              <h2 class="crop_name">Home Banner</h2>
          </td>
          <td class="right">
              <a href="<?php echo base_url('admin/manage_banner/') ?>" class="btn btn-xs btn-primary crop-edit">Manage</a>
          </td>
        </tr>
        <tr>
          <td class="hidden-xs visible-sm visible-md visible-lg">
              <h2 class="crop_name">Information Banner</h2>
          </td>
          <td class="right">
              <a href="<?php echo base_url('admin/info_banner/') ?>" class="btn btn-xs btn-primary crop-edit">Manage</a>
          </td>
        </tr>



    </tbody>
</table>
</div><!-- /.users -->

    </div><!-- /.col-* -->


</div><!-- /.row -->
</div><!-- /.col-* -->

                                </div>
                            </div><!-- /.container-fluid -->
                        </div><!-- /.content-admin-main-inner -->
                    </div><!-- /.content-admin-main -->
