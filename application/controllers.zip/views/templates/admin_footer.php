<div class="content-admin-footer">
    <div class="container-fluid">
        <div class="content-admin-footer-inner">
            &copy; 2018 Growcropsonline All rights reserved. Created by <a href="#">Greenmouse</a>.
        </div><!-- /.content-admin-footer-inner -->
    </div><!-- /.container-fluid -->
</div><!-- /.content-admin-footer  -->
</div><!-- /.content-admin-wrapper -->
</div><!-- /.content-admin -->
</div><!-- /.wrapper-admin -->
</div><!-- /.outer-admin -->
</div><!-- /.main -->
</div><!-- /.page-wrapper -->

<script type='text/javascript' src="<?php echo asset_url('js/map.js'); ?>"></script>

<script type='text/javascript' src="<?php echo asset_url('js/collapse.js'); ?>"></script>
<script type='text/javascript' src="<?php echo asset_url('js/carousel.js'); ?>"></script>
<script type='text/javascript' src="<?php echo asset_url('js/transition.js'); ?>"></script>
<script src="<?php echo asset_url('js/dropdown.js'); ?>" type="text/javascript"></script>

<script type='text/javascript' src="<?php echo asset_url('js/tooltip.js'); ?>"></script>
<script type='text/javascript' src="<?php echo asset_url('js/tab.js'); ?>"></script>
<script type='text/javascript' src="<?php echo asset_url('js/alert.js'); ?>"></script>

<script type='text/javascript' src="<?php echo asset_url('js/jquery.colorbox-min.js'); ?>"></script>

<script type='text/javascript' src="<?php echo asset_url('js/jquery.flot.min.js'); ?>"></script>
<script type='text/javascript' src="<?php echo asset_url('js/jquery.flot.spline.js'); ?>"></script>




<script type='text/javascript' src="<?php echo asset_url('js/owl.carousel.js'); ?>"></script>
<script type='text/javascript' src="<?php echo asset_url('js/slick.js'); ?>"></script>
<script type='text/javascript' src="<?php echo asset_url('js/fileinput.min.js'); ?>"></script>
<script type='text/javascript' src="<?php echo asset_url('js/selectize.min.js'); ?>"></script>
<script type='text/javascript' src="<?php echo asset_url('js/superlist.js'); ?>"></script>
<script type='text/javascript' src="<?php echo asset_url('js/jquery.rotapie.js'); ?>"></script>
<script type='text/javascript' src="<?php echo asset_url('js/tinymce.min.js'); ?>"></script>
<script type='text/javascript' src="<?php echo asset_url('js/jquery.tinymce.min.js'); ?>"></script>
<script src="<?php echo asset_url('js/datatables.buttons.min.js') ?>" type="text/javascript"></script>
<script src="<?php echo asset_url('js/buttons.flash.min.js') ?>" type="text/javascript"></script>
<script src="<?php echo asset_url('js/jszip.min.js'); ?>" type="text/javascript"></script>
<script src="<?php echo asset_url('js/pdfmake.min.js'); ?>" type="text/javascript"></script>
<script src="<?php echo asset_url('js/vfs_fonts.js'); ?>" type="text/javascript"></script>
<script src="<?php echo asset_url('js/buttons.html5.min.js'); ?>" type="text/javascript"></script>
<script src="<?php echo asset_url('js/buttons.print.min.js'); ?>" type="text/javascript"></script>

<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<script src="https://use.fontawesome.com/8aa91007f2.js"></script>

</body>
<script type="text/javascript">
$(document).ajaxStart(function() {
     Pace.restart();
});
</script>

</html>
